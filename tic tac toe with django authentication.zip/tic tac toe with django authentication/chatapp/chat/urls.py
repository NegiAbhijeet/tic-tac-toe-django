from unicodedata import name
from django.urls import path
from chat import views
urlpatterns = [
    path('',views.index,name="index"),
    path('signup',views.signup,name="signup"),
    path('login',views.login_function,name="login"),
    path('logout',views.logout_function,name="logout"),
    # path('search',views.search,name="search"),
    path('<str:room_name>/',views.room,name="room")

]