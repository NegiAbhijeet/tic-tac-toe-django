from asyncio import shield
from django.shortcuts import redirect, render,HttpResponseRedirect
from .forms import SignupForm,LoginForm
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout

from django.contrib.auth.models import User
li=[]
# Create your views here.
def index(request):
    
    if request.user.is_authenticated:
        # if request.method=='POST':
            
        #     myusername=request.user.username;
        #     if myusername not in li:
        #         li.append(request.user.username)
        #         print(li)
        #     async def find():

        #         await shield(if len(li)>1:return HttpResponseRedirect('/'+li[0]+li[1]) )
        #     # if len(li)>1:
                
            # else:
            #     return HttpResponseRedirect('/')
        return render(request,'index.html',{'name':request.user})
    else:
        return HttpResponseRedirect('/login')

def signup(request):
    if request.method=="POST":
        fm=SignupForm(request.POST)
        if fm.is_valid():
            messages.success(request,"User Successfully created")
            fm.save()
    else:
        fm=SignupForm()
    return render(request,'signup.html',{'form':fm})

def login_function(request):
    if not request.user.is_authenticated:
        if request.method=="POST":
            fm=LoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname=fm.cleaned_data['username']
                upass=fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    return HttpResponseRedirect('/')
        else:
            fm=LoginForm()
        return render(request,'login.html',{'form':fm})
    else:
        return HttpResponseRedirect('/')

def logout_function(request):
    logout(request)
    return HttpResponseRedirect('/login')

def room(request,room_name):
    if request.user.is_authenticated:
        return render(request,'chatroom.html',{
            'room_name': room_name,
        })
    else:
        return HttpResponseRedirect('/login')
    